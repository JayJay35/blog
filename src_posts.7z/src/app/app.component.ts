import { Component } from '@angular/core';
import { Post } from './models/post.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Posts';

  posts: Post[] = [
    new Post("Mon premier post"),
    new Post("Mon deuxième post"),
    new Post("Mon troisième post")
  ];

  constructor(){
    this.posts.forEach(post => {
      post.setContent("test 1234");
    });
  }
}
