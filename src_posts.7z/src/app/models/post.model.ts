export class Post {
    private content: string;
    private loveIts: number;
    private created_at: Date;

    constructor(private title: string) {
        this.created_at = new Date();
        this.loveIts = 0;
    }

    getTitle():string {
        return this.title;
    }

    getContent():string {
        return this.content;
    }

    getCreated_at():Date {
        return this.created_at;
    }

    getLoveIts():number {
        return this.loveIts;
    }

    setContent(content: string) {
        this.content = content;
    }

    loveIt() {
        this.loveIts++;
    }

    dontLoveIt() {
        this.loveIts--;
    }
}