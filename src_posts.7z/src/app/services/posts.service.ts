import { Injectable } from "@angular/core";
import { Post } from "../models/post.model";

@Injectable()
export class PostsService {
    posts: Post[];

    constructor() {
        this.getPosts();
    }

    getPosts() {
        this.posts = [
            new Post("Mon premier post"),
            new Post("Mon deuxième post"),
            new Post("Mon troisième post")
        ];
    }

}